﻿namespace final
{
    partial class CsHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CsHome));
            this.sidebar = new System.Windows.Forms.FlowLayoutPanel();
            this.Menu_btn = new System.Windows.Forms.PictureBox();
            this.Home = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.menuContainer = new System.Windows.Forms.FlowLayoutPanel();
            this.Trans = new System.Windows.Forms.Panel();
            this.tran_btn = new System.Windows.Forms.Button();
            this.transaction = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.orders = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.reservation = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Settings = new System.Windows.Forms.Button();
            this.Logout = new System.Windows.Forms.Panel();
            this.logout_btn = new System.Windows.Forms.Button();
            this.menuTransition = new System.Windows.Forms.Timer(this.components);
            this.sideBarTransition = new System.Windows.Forms.Timer(this.components);
            this.search = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.palabok = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pansit = new System.Windows.Forms.PictureBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.sidebar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Menu_btn)).BeginInit();
            this.Home.SuspendLayout();
            this.menuContainer.SuspendLayout();
            this.Trans.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.Logout.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.palabok)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pansit)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            this.SuspendLayout();
            // 
            // sidebar
            // 
            this.sidebar.BackColor = System.Drawing.SystemColors.ControlLight;
            this.sidebar.Controls.Add(this.Menu_btn);
            this.sidebar.Controls.Add(this.Home);
            this.sidebar.Controls.Add(this.menuContainer);
            this.sidebar.Controls.Add(this.panel5);
            this.sidebar.Controls.Add(this.Logout);
            this.sidebar.Location = new System.Drawing.Point(0, -3);
            this.sidebar.Name = "sidebar";
            this.sidebar.Size = new System.Drawing.Size(193, 514);
            this.sidebar.TabIndex = 1;
            // 
            // Menu_btn
            // 
            this.Menu_btn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Menu_btn.Image = ((System.Drawing.Image)(resources.GetObject("Menu_btn.Image")));
            this.Menu_btn.Location = new System.Drawing.Point(10, 10);
            this.Menu_btn.Margin = new System.Windows.Forms.Padding(10, 10, 3, 3);
            this.Menu_btn.Name = "Menu_btn";
            this.Menu_btn.Size = new System.Drawing.Size(30, 30);
            this.Menu_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Menu_btn.TabIndex = 0;
            this.Menu_btn.TabStop = false;
            this.Menu_btn.Click += new System.EventHandler(this.sideBarTransition_Tick);
            // 
            // Home
            // 
            this.Home.Controls.Add(this.button2);
            this.Home.Location = new System.Drawing.Point(3, 53);
            this.Home.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(203, 61);
            this.Home.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Image = global::final.Properties.Resources.icons8_home_482;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(-30, -27);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.button2.Size = new System.Drawing.Size(250, 116);
            this.button2.TabIndex = 3;
            this.button2.Text = "Home";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // menuContainer
            // 
            this.menuContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.menuContainer.Controls.Add(this.Trans);
            this.menuContainer.Controls.Add(this.panel3);
            this.menuContainer.Controls.Add(this.panel4);
            this.menuContainer.Location = new System.Drawing.Point(0, 117);
            this.menuContainer.Margin = new System.Windows.Forms.Padding(0);
            this.menuContainer.Name = "menuContainer";
            this.menuContainer.Size = new System.Drawing.Size(232, 61);
            this.menuContainer.TabIndex = 6;
            // 
            // Trans
            // 
            this.Trans.Controls.Add(this.tran_btn);
            this.Trans.Controls.Add(this.transaction);
            this.Trans.Location = new System.Drawing.Point(0, 0);
            this.Trans.Margin = new System.Windows.Forms.Padding(0);
            this.Trans.Name = "Trans";
            this.Trans.Size = new System.Drawing.Size(239, 61);
            this.Trans.TabIndex = 5;
            // 
            // tran_btn
            // 
            this.tran_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tran_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(158)))), ((int)(((byte)(158)))));
            this.tran_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.tran_btn.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tran_btn.Image = global::final.Properties.Resources.icons8_transaction_48;
            this.tran_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tran_btn.Location = new System.Drawing.Point(-11, -26);
            this.tran_btn.Name = "tran_btn";
            this.tran_btn.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.tran_btn.Size = new System.Drawing.Size(250, 116);
            this.tran_btn.TabIndex = 3;
            this.tran_btn.Text = "Transaction";
            this.tran_btn.UseVisualStyleBackColor = false;
            this.tran_btn.Click += new System.EventHandler(this.tran_btn_Click);
            // 
            // transaction
            // 
            this.transaction.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.transaction.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(156)))));
            this.transaction.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.transaction.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.transaction.Image = global::final.Properties.Resources.icons8_transaction_48;
            this.transaction.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.transaction.Location = new System.Drawing.Point(3, 185);
            this.transaction.Name = "transaction";
            this.transaction.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.transaction.Size = new System.Drawing.Size(262, 89);
            this.transaction.TabIndex = 3;
            this.transaction.Text = "Transactions";
            this.transaction.UseVisualStyleBackColor = false;
            this.transaction.Click += new System.EventHandler(this.transaction_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.orders);
            this.panel3.Location = new System.Drawing.Point(0, 71);
            this.panel3.Margin = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(239, 61);
            this.panel3.TabIndex = 6;
            // 
            // orders
            // 
            this.orders.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.orders.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.orders.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.orders.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orders.Image = global::final.Properties.Resources.icons8_cart_48;
            this.orders.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.orders.Location = new System.Drawing.Point(-7, -14);
            this.orders.Name = "orders";
            this.orders.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.orders.Size = new System.Drawing.Size(262, 89);
            this.orders.TabIndex = 4;
            this.orders.Text = "Orders";
            this.orders.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.reservation);
            this.panel4.Location = new System.Drawing.Point(0, 137);
            this.panel4.Margin = new System.Windows.Forms.Padding(0, 5, 0, 10);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(239, 61);
            this.panel4.TabIndex = 7;
            // 
            // reservation
            // 
            this.reservation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.reservation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.reservation.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.reservation.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reservation.Image = global::final.Properties.Resources.icons8_reservation_48;
            this.reservation.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.reservation.Location = new System.Drawing.Point(-12, -12);
            this.reservation.Name = "reservation";
            this.reservation.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.reservation.Size = new System.Drawing.Size(262, 89);
            this.reservation.TabIndex = 5;
            this.reservation.Text = "Reservation";
            this.reservation.UseVisualStyleBackColor = false;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.Settings);
            this.panel5.Location = new System.Drawing.Point(3, 181);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(203, 61);
            this.panel5.TabIndex = 7;
            // 
            // Settings
            // 
            this.Settings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Settings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Settings.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Settings.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Settings.Image = global::final.Properties.Resources.icons8_settings_48;
            this.Settings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Settings.Location = new System.Drawing.Point(-30, -27);
            this.Settings.Name = "Settings";
            this.Settings.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.Settings.Size = new System.Drawing.Size(250, 116);
            this.Settings.TabIndex = 3;
            this.Settings.Text = "Settings";
            this.Settings.UseVisualStyleBackColor = false;
            // 
            // Logout
            // 
            this.Logout.Controls.Add(this.logout_btn);
            this.Logout.Location = new System.Drawing.Point(3, 248);
            this.Logout.Name = "Logout";
            this.Logout.Size = new System.Drawing.Size(203, 61);
            this.Logout.TabIndex = 7;
            // 
            // logout_btn
            // 
            this.logout_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.logout_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.logout_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.logout_btn.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logout_btn.Image = global::final.Properties.Resources.icons8_logout_30;
            this.logout_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.logout_btn.Location = new System.Drawing.Point(-30, -27);
            this.logout_btn.Name = "logout_btn";
            this.logout_btn.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.logout_btn.Size = new System.Drawing.Size(250, 116);
            this.logout_btn.TabIndex = 3;
            this.logout_btn.Text = "Logout";
            this.logout_btn.UseVisualStyleBackColor = false;
            // 
            // menuTransition
            // 
            this.menuTransition.Interval = 10;
            this.menuTransition.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // sideBarTransition
            // 
            this.sideBarTransition.Interval = 10;
            // 
            // search
            // 
            this.search.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.search.Location = new System.Drawing.Point(193, 7);
            this.search.Multiline = true;
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(371, 30);
            this.search.TabIndex = 2;
            this.search.Text = "Search Product";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.panel2);
            this.flowLayoutPanel1.Controls.Add(this.panel6);
            this.flowLayoutPanel1.Controls.Add(this.panel10);
            this.flowLayoutPanel1.Controls.Add(this.panel7);
            this.flowLayoutPanel1.Controls.Add(this.panel1);
            this.flowLayoutPanel1.Controls.Add(this.pictureBox7);
            this.flowLayoutPanel1.Controls.Add(this.pictureBox11);
            this.flowLayoutPanel1.Controls.Add(this.pictureBox8);
            this.flowLayoutPanel1.Controls.Add(this.pictureBox9);
            this.flowLayoutPanel1.Controls.Add(this.pictureBox14);
            this.flowLayoutPanel1.Controls.Add(this.pictureBox15);
            this.flowLayoutPanel1.Controls.Add(this.pictureBox16);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(199, 102);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(365, 397);
            this.flowLayoutPanel1.TabIndex = 9;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.palabok);
            this.panel2.Location = new System.Drawing.Point(6, 10);
            this.panel2.Margin = new System.Windows.Forms.Padding(6, 10, 3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(107, 103);
            this.panel2.TabIndex = 5;
            // 
            // palabok
            // 
            this.palabok.Image = global::final.Properties.Resources.d57a26e66e4ebfd3bc40583a8fb60778;
            this.palabok.Location = new System.Drawing.Point(-3, -3);
            this.palabok.Name = "palabok";
            this.palabok.Size = new System.Drawing.Size(107, 103);
            this.palabok.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.palabok.TabIndex = 4;
            this.palabok.TabStop = false;
            this.palabok.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.pansit);
            this.panel6.Location = new System.Drawing.Point(122, 10);
            this.panel6.Margin = new System.Windows.Forms.Padding(6, 10, 3, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(107, 103);
            this.panel6.TabIndex = 6;
            // 
            // pansit
            // 
            this.pansit.Image = global::final.Properties.Resources._4a51a7b0b89897e25c12c9410465b188;
            this.pansit.Location = new System.Drawing.Point(0, 0);
            this.pansit.Name = "pansit";
            this.pansit.Size = new System.Drawing.Size(107, 103);
            this.pansit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pansit.TabIndex = 4;
            this.pansit.TabStop = false;
            this.pansit.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.pictureBox4);
            this.panel10.Location = new System.Drawing.Point(238, 10);
            this.panel10.Margin = new System.Windows.Forms.Padding(6, 10, 3, 3);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(107, 103);
            this.panel10.TabIndex = 5;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::final.Properties.Resources.d57a26e66e4ebfd3bc40583a8fb60778;
            this.pictureBox4.Location = new System.Drawing.Point(1, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(107, 103);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.pictureBox6);
            this.panel7.Location = new System.Drawing.Point(6, 126);
            this.panel7.Margin = new System.Windows.Forms.Padding(6, 10, 3, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(107, 103);
            this.panel7.TabIndex = 5;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::final.Properties.Resources.d57a26e66e4ebfd3bc40583a8fb60778;
            this.pictureBox6.Location = new System.Drawing.Point(1, 0);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(107, 103);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 4;
            this.pictureBox6.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Location = new System.Drawing.Point(122, 126);
            this.panel1.Margin = new System.Windows.Forms.Padding(6, 10, 3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(107, 103);
            this.panel1.TabIndex = 5;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::final.Properties.Resources.d57a26e66e4ebfd3bc40583a8fb60778;
            this.pictureBox5.Location = new System.Drawing.Point(1, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(107, 103);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::final.Properties.Resources.d57a26e66e4ebfd3bc40583a8fb60778;
            this.pictureBox7.Location = new System.Drawing.Point(235, 126);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(107, 103);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 4;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::final.Properties.Resources.d57a26e66e4ebfd3bc40583a8fb60778;
            this.pictureBox11.Location = new System.Drawing.Point(3, 235);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(107, 103);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 4;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::final.Properties.Resources.d57a26e66e4ebfd3bc40583a8fb60778;
            this.pictureBox8.Location = new System.Drawing.Point(116, 235);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(107, 103);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 4;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::final.Properties.Resources.d57a26e66e4ebfd3bc40583a8fb60778;
            this.pictureBox9.Location = new System.Drawing.Point(229, 235);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(107, 103);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 4;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::final.Properties.Resources.d57a26e66e4ebfd3bc40583a8fb60778;
            this.pictureBox14.Location = new System.Drawing.Point(3, 344);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(107, 103);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 9;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::final.Properties.Resources.d57a26e66e4ebfd3bc40583a8fb60778;
            this.pictureBox15.Location = new System.Drawing.Point(116, 344);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(107, 103);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 10;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::final.Properties.Resources.d57a26e66e4ebfd3bc40583a8fb60778;
            this.pictureBox16.Location = new System.Drawing.Point(229, 344);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(107, 103);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 11;
            this.pictureBox16.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(210, 60);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(77, 22);
            this.button1.TabIndex = 10;
            this.button1.Text = "All";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(459, 60);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(77, 22);
            this.button3.TabIndex = 11;
            this.button3.Text = "Dinner";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(293, 60);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(77, 22);
            this.button4.TabIndex = 12;
            this.button4.Text = "Breakfast";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(376, 60);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(77, 22);
            this.button5.TabIndex = 13;
            this.button5.Text = "Lunch";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // CsHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 511);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.search);
            this.Controls.Add(this.sidebar);
            this.Controls.Add(this.flowLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "CsHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CsHome";
            this.sidebar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Menu_btn)).EndInit();
            this.Home.ResumeLayout(false);
            this.menuContainer.ResumeLayout(false);
            this.Trans.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.Logout.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.palabok)).EndInit();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pansit)).EndInit();
            this.panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Menu_btn;
        private System.Windows.Forms.FlowLayoutPanel sidebar;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel Home;
        private System.Windows.Forms.Panel Trans;
        private System.Windows.Forms.Button transaction;
        private System.Windows.Forms.FlowLayoutPanel menuContainer;
        private System.Windows.Forms.Panel Logout;
        private System.Windows.Forms.Button logout_btn;
        private System.Windows.Forms.Button reservation;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Timer menuTransition;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button orders;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button Settings;
        private System.Windows.Forms.Timer sideBarTransition;
        private System.Windows.Forms.TextBox search;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button tran_btn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox palabok;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pansit;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
    }
}
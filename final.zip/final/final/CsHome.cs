﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace final
{
    public partial class CsHome : Form
    {


        public CsHome()
        {
            InitializeComponent();
            menuContainer.Height = 61; 
            sidebar.Width = 193; 
        }

        bool menuExpand = false;
        bool sidebarExpand = true;

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (menuExpand == false)
            {
                menuContainer.Height += 10;
                if (menuContainer.Height >= 198)
                {
                    menuTransition.Stop();
                    menuExpand = true;
                }
            }
            else
            {
                menuContainer.Height -= 10;
                if (menuContainer.Height <= 61)
                {
                    menuTransition.Stop();
                    menuExpand = false;
                }
            }
        }

        private void transaction_Click(object sender, EventArgs e)
        {
            menuTransition.Start();
        }

        private void sideBarTransition_Tick(object sender, EventArgs e)
        {

        }

        private void Menu_btn_Click(object sender, EventArgs e)
        {
            sideBarTransition.Start();
        }

        private void tran_btn_Click(object sender, EventArgs e)
        {
            menuTransition.Start();
        }

        public void pictureBox2_Click(object sender, EventArgs e)
        {
            product pr = new product();
            pr.Show();

            palabok.BringToFront();

            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            product pr2 = new product();
            pr2.Show();
            pansit.BringToFront();
            this.Hide();
        }

        private void logout_btn_Click(object sender, EventArgs e)
        {
            hide_btn lform = new hide_btn();   
            lform.Show();
            this.Hide();
        }

    }
}
